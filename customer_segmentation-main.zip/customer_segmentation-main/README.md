# customer_segmentation
Customers segmentation using clustering models to give products and services recommendations
